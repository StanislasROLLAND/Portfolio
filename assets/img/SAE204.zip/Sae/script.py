import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Chargement des données
MondataFrame = pd.read_csv("/home/etuinfo/nbarbotaud/Documents/travail/iut/S2/saebdd/vue1.csv", delimiter=';')

# Afficher les noms des colonnes pour vérifier les noms corrects
print("Colonnes du DataFrame :")
print(MondataFrame.columns)

# Suppression des valeurs manquantes
MondataFrame = MondataFrame.dropna()

# Conversion en array NumPy
CollegesAR = np.array(MondataFrame)

# Exclusion de la première ligne si nécessaire (par exemple si c'est une ligne d'en-tête)
CollegesAR = CollegesAR[1:]

# Sélection des colonnes d'intérêt (ajustez les indices selon vos besoins)
CollegesAR0 = CollegesAR[:, [1, 2, 3, 4, 5]].astype(np.float64)

print("Données sélectionnées pour le calcul de la matrice de covariance:")
print(CollegesAR0)

# Définition de la fonction Centreduire
def Centreduire(T):
    T = np.array(T, dtype=np.float64)
    moyennes = np.mean(T, axis=0)
    ecarts_types = np.std(T, axis=0)
    Res = (T - moyennes) / ecarts_types
    return Res

# Calcul de la matrice de covariance
matrice_covariance = np.cov(Centreduire(CollegesAR0), rowvar=False)
print("Matrice de covariance:")
print(matrice_covariance)

# Sélection des colonnes avec les noms corrects
X = MondataFrame[['latitude', 'longitude', 'nb_candidats_g', 'nombre_d_eleves']].astype(float)
y = MondataFrame['taux_de_reussite_g'].astype(float)

# Instanciation du modèle
model = LinearRegression()

# Entraînement du modèle
model.fit(X, y)

# Extraction des coefficients
coefficients = model.coef_
intercept = model.intercept_

print("Coefficients :", coefficients)
print("Intercept :", intercept)

# Prédiction
y_pred = model.predict(X)

# Visualisation des résultats
plt.scatter(y, y_pred)
plt.xlabel("Taux de Réussite Réel")
plt.ylabel("Taux de Réussite Prédit")
plt.title("Réel vs Prédit")
plt.show()

# Calcul du coefficient de détermination (R^2)
r_squared = model.score(X, y)
print("Coefficient de détermination R^2 :", r_squared)
