/**
* \brief Programme d'un jeu de Sudoku.
* \author ROLLAND Stanislas
* \version 1.3
* \date 24/11/2023
* Ce programme permet à un utilisateur de jouer une partie de Sudoku.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/**************************************************
*  DEFINITION DES CONSTANTES ET DU TYPE UTILISES  *
**************************************************/

/**
* \def N
* \brief constante pour la taille.
*/
#define N 3

/**
* \def TAILLE
* \brief constante pour la taille d'un tableau.
*/
#define TAILLE N*N

/**
* \def VALEUR_MINIMUM
* \brief constante pour la valeur minimum que l'utilisateur puisse saisir.
*/
#define VALEUR_MINIMUM 1

/**
* \typedef tGrille
* \brief type tableau de TAILLE lignes et TAILLE colonnes.
* Le type typTab sert de stockage provisoire pour ordonner
* les éléments (caractères) d’une liste.
*/
typedef int tGrille[TAILLE][TAILLE];

/*****************************************************
*  PROTOTYPES DES PROCEDURES ET FONCTIONS UTILISEES  *
*****************************************************/

void chargerGrille(tGrille g);
void afficherGrille(tGrille g);
void saisir(int *s);
bool possible(tGrille g, int numLigne, int numColonne, int valeur);
bool possibleLigne(tGrille g, int numLigne, int valeur);
bool possibleColonne(tGrille g, int numColonne, int valeur);
bool possibleBloc(tGrille g, int numLigne, int numColonne, int valeur);
bool etatGrille(tGrille g);

/************************
*  PROGRAMME PRINCIPAL  *
************************/

int main(){
    tGrille grille1;
    int numLigne, numColonne, valeur;
    chargerGrille(grille1);
    while(etatGrille(grille1)){
        afficherGrille(grille1);
        printf("Indices de la case ? \n");
        saisir(&numLigne);
        saisir(&numColonne);
        if(grille1[numLigne-1][numColonne-1]!=0){
            printf("IMPOSSIBLE, la case n'est pas libre.\n");
        }
        else{
            printf("Valeur à insérer ? \n");
            saisir(&valeur);
            if(possible(grille1, numLigne, numColonne, valeur)){
                grille1[numLigne-1][numColonne-1] = valeur;
            }
        }
    }
    afficherGrille(grille1);
    printf("Grille pleine, fin de partie\n");
}

/**************************************
*  CHARGEMENT D'UNE GRILLE DE SUDOKU  *
**************************************/

/**
* \fn void chargerGrille(tGrille g)
* \brief Procédure qui permet de charger une grille de jeu de Sudoku.
* \param g : le tableau en 2D contenant les éléments qui représentent la grille de Sudoku.
* Consiste à charger une grille de Sudoku à partir d'un fichier extérieur au programme.
*/
void chargerGrille(tGrille g){
    char nomFichier[30];
    FILE * f;
    printf("Nom du fichier ? ");
    scanf("%s", nomFichier);
    f = fopen(nomFichier, "rb");
    if (f==NULL){
        printf("\n ERREUR sur le fichier %s\n", nomFichier);
    } else {
        fread(g, sizeof(int), TAILLE*TAILLE, f);
    }
    fclose(f);
}

/*************************************
*  AFFICHAGE D'UNE GRILLE DE SUDOKU  *
*************************************/

/**
* \fn void afficherGrille(tGrille g)
* \brief Procédure qui permet d'afficher les éléments du tableau g passé en pramètre.
* \param g : le tableau en 2D contenant les éléments qui représentent la grille de Sudoku.
* Consiste à afficher la grille de Sudoku de façon formatée pour qu'elle soit plus lisible par l'utilisateur.
*/
void afficherGrille(tGrille g){
    int ligne,colonne;
    int compteur=1;
    printf("      1  2  3   4  5  6   7  8  9\n");
    for(ligne=0;ligne!=TAILLE;ligne++){
        if(ligne%N==0){
            printf("    +---------+---------+---------+\n");
        }
        printf("%d   ",compteur);
        for(colonne=0;colonne<TAILLE;colonne++){
            if(colonne%N==0){
                printf("|");
            }
            if(g[ligne][colonne]!=0){
                printf(" %d ",g[ligne][colonne]);
            }
            else{
                printf(" . ");
            }
        }
        printf("|");
        printf("\n");
        compteur++;
    }
    printf("    +---------+---------+---------+\n");
}

/*******************************************************
*  VERIFICATION DES VALEURS SAISIES PAR L'UTILISATEUR  *
*******************************************************/

/**
* \fn void saisir(int *s)
* \brief Procédure qui permet de lire ce que l'utilisateur a saisi au clavier.
* \param s : variable qui prendra comme valeur la valeur saisie par l'utilisateur.
* Consiste à lire ce que l'utilisateur a saisi au clavier et ce jusqu'à ce que l'utilisateur renseigne une valeur utilisable.
*/
void saisir(int *s){
    char ch[20];
    int x;
    do{
        scanf("%s", ch);
        if (sscanf(ch, "%d", &x) !=0){  // la conversion a réussi, x contient la valeur entière lue au clavier
            if((x>=VALEUR_MINIMUM)&&(x<=TAILLE)){
                *s=x;
            }
            else{
                printf("ERREUR, la valeur saisie n'est pas comprise entre 1 et 9. Veuillez recommencer : \n");
            }
        } 
        else{    //la conversion :en entier a échoué
            printf("ERREUR, la valeur saisie ne peut être utilisée. Veuillez recommencer : \n");
        }
    }while((x<VALEUR_MINIMUM)&&(x>TAILLE));
}

/**************************************************************************************************
*  VERIFICATION SI LA VALEUR CHOISIE PAR L'UTILISATEUR PEUT ETRE PLACEE DANS LA GRILLE DE SUDOKU  *
**************************************************************************************************/

/**
* \fn bool possible(tGrille g, int numLigne, int numColonne, int valeur)
* \brief Fonction qui indique si on peut placer une valeur à une position donnée dans un tableau.
* \param g : le tableau en 2D contenant les éléments qui représentent la grille de Sudoku.
* \param numLigne : l'indice de la ligne à laquelle l'utilisateur souhaite placer sa valeur.
* \param valeur : la valeur que l'utilisateur souhaite placer.
* \return true si la valeur peut être placée à la position souhaitée, false sinon.
* Consiste à vérifier si la valeur que l'utilisateur souhaite placer dans le tableau n'est pas déjà présente dans la ligne et 
* la colonne auxquelles il souhaite la placer. Elle vérifie égalemment si cette valeur n'est pas présente dans la sous-grille des 
* indice de ligne et de colonne choisis par l'utilisateur.
*/
bool possible(tGrille g, int numLigne, int numColonne, int valeur){
    bool res=false;
    if((possibleLigne(g,numLigne,valeur))&&(possibleColonne(g,numColonne,valeur))&&(possibleBloc(g,numLigne,numColonne,valeur))){
        res=true;
    }
    return res;
}

/**
* \fn bool possibleLigne(tGrille g, int numLigne, int valeur)
* \brief Fonction qui indique si une valeur est déjà présente dans une ligne d'une grille de Sudoku.
* \param g : le tableau en 2D contenant les éléments qui représentent la grille de Sudoku.
* \param numLigne : l'indice de la ligne à laquelle l'utilisateur souhaite placer sa valeur.
* \param valeur : la valeur que l'utilisateur souhaite placer.
* \return true si la valeur n'est pas déjà présente dans la ligne choisie par l'utilisateur, false sinon.
* Consiste à vérifier si la valeur que l'utilisateur souhaite placer dans le tableau n'est pas déjà présente dans la ligne à
* laquelle il souhaite la placer.
*/
bool possibleLigne(tGrille g, int numLigne, int valeur){
    bool res=true;
    for(int colonne=0;colonne<TAILLE;colonne++){
        if(g[numLigne-1][colonne]==valeur){
            res=false;
            printf("La valeur que vous souhaiter placer (%d) est déjà présente dans la ligne [%d]\n",valeur,numLigne);
        }
    }
    return res;
}

/**
* \fn bool possibleColonne(tGrille g, int numColonne, int valeur)
* \brief Fonction qui indique si une valeur est déjà présente dans une colonne d'une grille de Sudoku.
* \param g : le tableau en 2D contenant les éléments qui représentent la grille de Sudoku.
* \param numColonne : l'indice de la colonne à laquelle l'utilisateur souhaite placer sa valeur.
* \param valeur : la valeur que l'utilisateur souhaite placer.
* \return true si la valeur n'est pas déjà présente dans la colonne choisie par l'utilisateur, false sinon.
* Consiste à vérifier si la valeur que l'utilisateur souhaite placer dans le tableau n'est pas déjà présente dans la colonne à
* laquelle il souhaite la placer.
*/
bool possibleColonne(tGrille g, int numColonne, int valeur){
    bool res=true;
    for(int ligne=0;ligne<TAILLE;ligne++){
        if(g[ligne][numColonne-1]==valeur){
            res=false;
            printf("La valeur que vous souhaiter placer (%d) est déjà présente dans la colonne [%d]\n",valeur,numColonne);
        }
    }
    return res;
}

/**
* \fn bool possibleBloc(tGrille g, int numLigne, int numColonne, int valeur)
* \brief Fonction qui indique si on peut placer une valeur est déjà présente dans une sous-grille d'une grille de Sudoku.
* \param g : le tableau en 2D contenant les éléments qui représentent la grille de Sudoku.
* \param numLigne : l'indice de la ligne à laquelle l'utilisateur souhaite placer sa valeur.
* \param numColonne : l'indice de la colonne à laquelle l'utilisateur souhaite placer sa valeur.
* \param valeur : la valeur que l'utilisateur souhaite placer.
* \return true si la valeur n'est pas déjà présente dans la sous-grille des indice de ligne et de colonne choisis par l'utilisateur, false sinon.
* Consiste à vérifier si la valeur que l'utilisateur souhaite placer dans le tableau n'est pas déjà dans la sous-grille des indice de ligne et de 
* colonne il souhaite la placer.
*/
bool possibleBloc(tGrille g, int numLigne, int numColonne, int valeur){
    bool res=true;
    int debut_ligne=((numLigne-1)/N)*N;
    int debut_colonne=((numColonne-1)/N)*N;
    for(int ligne=0;ligne<N;ligne++){ 
        for(int colonne=0;colonne<N;colonne++){
            if(g[debut_ligne+ligne][debut_colonne+colonne]==valeur){
                res=false;
                printf("La valeur que vous souhaiter placer (%d) est déjà présente dans la sous-grille [%d][%d]\n",valeur,(debut_ligne+1),(debut_colonne+1));
            }
        }
    }
    return res;
}

/********************************************************
*  VERIFICATION DE L'ETAT DE LA GRILLE (PLEINE OU NON)  *
********************************************************/

/**
* \fn bool etatGrille(tGrille g)
* \brief Fonction qui indique si le tableau g contient la valeur 0.
* \param g : le tableau en 2D contenant les éléments qui représentent la grille de Sudoku.
* \return true si le tableau contient la valeur 0, false sinon.
*/
bool etatGrille(tGrille g){
    bool res=false;
    for(int ligne=0;ligne!=TAILLE;ligne++){
        for(int colonne=0;colonne!=TAILLE;colonne++){
            if(g[ligne][colonne]==0){
                res=true;
            }
        }
    }
    return res;
}